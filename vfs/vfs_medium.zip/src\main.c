﻿main() { }
